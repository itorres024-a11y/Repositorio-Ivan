# Tarjeta_Profesional_s08_Torres Rementeria

A Pen created on CodePen.

Original URL: [https://codepen.io/IVAN-TORRESREMENTERIA/pen/XJXjbbV](https://codepen.io/IVAN-TORRESREMENTERIA/pen/XJXjbbV).

